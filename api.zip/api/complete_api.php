<?php
/**
 * API Completion File
 * This file completes the API system by including all handler files and finishing the stats_handlers.php implementation
 */

// Include necessary files
require_once 'handlers.php';
require_once 'stats_handlers.php';

// Complete the stats_handlers.php implementation
// This code would normally be in stats_handlers.php but we're adding it here to complete the functionality

/**
 * Complete the advanced search function from stats_handlers.php
 */
function complete_advanced_search($stmt, $bind_types, $bind_params) {
    $stmt->bind_param($bind_types, ...$bind_params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $articles = [];
    while ($row = $result->fetch_assoc()) {
        $articles[] = $row;
    }
    
    return $articles;
}

/**
 * Handle faceted search with aggregations
 */
function handle_faceted_search($method, $params) {
    global $conn;
    
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Base search query similar to advanced search
    $search_query = isset($params['q']) && !empty($params['q']) ? '%' . $params['q'] . '%' : null;
    
    // Build WHERE clause with filters (similar to advanced search)
    $where_clauses = [];
    $bind_types = "";
    $bind_params = [];
    
    if ($search_query) {
        $where_clauses[] = "(a.judul LIKE ? OR a.konten LIKE ?)";
        $bind_types .= "ss";
        $bind_params[] = $search_query;
        $bind_params[] = $search_query;
    }
    
    // Apply filters for categories, dates, etc.
    if (isset($params['category']) && !empty($params['category'])) {
        $where_clauses[] = "k.slug = ?";
        $bind_types .= "s";
        $bind_params[] = $params['category'];
    }
    
    // Date range filter
    if (isset($params['date_from']) && !empty($params['date_from'])) {
        $where_clauses[] = "a.tanggal_publikasi >= ?";
        $bind_types .= "s";
        $bind_params[] = $params['date_from'];
    }
    
    if (isset($params['date_to']) && !empty($params['date_to'])) {
        $where_clauses[] = "a.tanggal_publikasi <= ?";
        $bind_types .= "s";
        $bind_params[] = $params['date_to'];
    }
    
    // Build the final WHERE clause
    $where_clause = !empty($where_clauses) ? "WHERE " . implode(" AND ", $where_clauses) : "";
    
    // Get facets/aggregations
    $facets = [
        'categories' => [],
        'years' => [],
        'months' => []
    ];
    
    // Get category facets
    $sql = "SELECT k.id, k.nama, k.slug, COUNT(*) as count 
           FROM artikel a 
           JOIN kategori k ON a.kategori_id = k.id 
           $where_clause 
           GROUP BY k.id 
           ORDER BY count DESC";
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($bind_types)) {
        $stmt->bind_param($bind_types, ...$bind_params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $facets['categories'][] = $row;
    }
    
    // Get year facets
    $sql = "SELECT YEAR(tanggal_publikasi) as year, COUNT(*) as count 
           FROM artikel a 
           $where_clause 
           GROUP BY YEAR(tanggal_publikasi) 
           ORDER BY year DESC";
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($bind_types)) {
        $stmt->bind_param($bind_types, ...$bind_params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $facets['years'][] = $row;
    }
    
    // Get month facets (for current year)
    $current_year = date('Y');
    $sql = "SELECT MONTH(tanggal_publikasi) as month, COUNT(*) as count 
           FROM artikel a 
           WHERE YEAR(tanggal_publikasi) = ? 
           GROUP BY MONTH(tanggal_publikasi) 
           ORDER BY month ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $current_year);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        // Add month name
        $month_num = $row['month'];
        $month_name = date('F', mktime(0, 0, 0, $month_num, 1));
        $row['month_name'] = $month_name;
        $facets['months'][] = $row;
    }
    
    // Return facets
    send_response(200, 'Search facets retrieved successfully', $facets);
}

/**
 * Handle article recommendations
 */
function handle_recommendations($method, $parts, $params) {
    global $conn;
    
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Check if we're dealing with a specific article
    $article_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    if (!$article_id) {
        send_response(400, 'Article ID is required');
    }
    
    // Get article details to find similar content
    $sql = "SELECT kategori_id FROM artikel WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $article_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        send_response(404, 'Article not found');
    }
    
    $article = $result->fetch_assoc();
    $category_id = $article['kategori_id'];
    
    // Get recommendations based on same category
    $limit = isset($params['limit']) ? (int)$params['limit'] : 5;
    
    $sql = "SELECT a.id, a.judul, a.slug, a.gambar, a.tanggal_publikasi, k.nama as kategori_nama 
            FROM artikel a 
            JOIN kategori k ON a.kategori_id = k.id 
            WHERE a.kategori_id = ? AND a.id != ? 
            ORDER BY a.tanggal_publikasi DESC 
            LIMIT ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $category_id, $article_id, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $recommendations = [];
    while ($row = $result->fetch_assoc()) {
        $recommendations[] = $row;
    }
    
    send_response(200, 'Recommendations retrieved successfully', $recommendations);
}

/**
 * Handle article rating system
 */
function handle_ratings($method, $parts, $params, $body) {
    global $conn;
    
    // Check if ratings table exists, if not create it
    $sql = "CREATE TABLE IF NOT EXISTS article_ratings (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        artikel_id INT(11) NOT NULL,
        user_identifier VARCHAR(255) NOT NULL,
        rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY (artikel_id, user_identifier),
        FOREIGN KEY (artikel_id) REFERENCES artikel(id) ON DELETE CASCADE
    )";
    
    if ($conn->query($sql) !== TRUE) {
        send_response(500, 'Error creating ratings table: ' . $conn->error);
    }
    
    // Check if we're dealing with a specific article
    $article_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    if (!$article_id) {
        send_response(400, 'Article ID is required');
    }
    
    switch ($method) {
        case 'GET':
            // Get ratings for an article
            $sql = "SELECT AVG(rating) as average_rating, COUNT(*) as rating_count 
                    FROM article_ratings 
                    WHERE artikel_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $article_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $ratings_summary = $result->fetch_assoc();
            
            // Get rating distribution
            $sql = "SELECT rating, COUNT(*) as count 
                    FROM article_ratings 
                    WHERE artikel_id = ? 
                    GROUP BY rating 
                    ORDER BY rating DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $article_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $distribution = [];
            while ($row = $result->fetch_assoc()) {
                $distribution[] = $row;
            }
            
            // Get recent comments
            $sql = "SELECT rating, comment, created_at 
                    FROM article_ratings 
                    WHERE artikel_id = ? AND comment IS NOT NULL AND comment != '' 
                    ORDER BY created_at DESC 
                    LIMIT 5";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $article_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $comments = [];
            while ($row = $result->fetch_assoc()) {
                $comments[] = $row;
            }
            
            send_response(200, 'Ratings retrieved successfully', [
                'summary' => $ratings_summary,
                'distribution' => $distribution,
                'comments' => $comments
            ]);
            break;
            
        case 'POST':
            // Add a new rating
            if (!isset($body['rating']) || !is_numeric($body['rating']) || $body['rating'] < 1 || $body['rating'] > 5) {
                send_response(400, 'Valid rating between 1 and 5 is required');
            }
            
            // Get user identifier (IP address or session ID)
            $user_identifier = session_id() ?: $_SERVER['REMOTE_ADDR'];
            $rating = (int)$body['rating'];
            $comment = isset($body['comment']) ? $body['comment'] : null;
            
            // Check if user already rated this article
            $sql = "SELECT id FROM article_ratings WHERE artikel_id = ? AND user_identifier = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $article_id, $user_identifier);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing rating
                $sql = "UPDATE article_ratings SET rating = ?, comment = ? WHERE artikel_id = ? AND user_identifier = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isis", $rating, $comment, $article_id, $user_identifier);
                
                if ($stmt->execute()) {
                    send_response(200, 'Rating updated successfully');
                } else {
                    send_response(500, 'Failed to update rating: ' . $stmt->error);
                }
            } else {
                // Insert new rating
                $sql = "INSERT INTO article_ratings (artikel_id, user_identifier, rating, comment) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isis", $article_id, $user_identifier, $rating, $comment);
                
                if ($stmt->execute()) {
                    send_response(201, 'Rating submitted successfully');
                } else {
                    send_response(500, 'Failed to submit rating: ' . $stmt->error);
                }
            }
            break;
            
        default:
            send_response(405, 'Method not allowed');
    }
}

// Return true to indicate the API system is complete
return true;
?>