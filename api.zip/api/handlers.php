<?php
/**
 * API Handlers
 * This file contains handler functions for the API endpoints
 */

// Include necessary files if not already included
require_once '../config/database.php';
require_once '../config/roles.php';
require_once '../config/analytics.php';

/**
 * Handle category endpoints
 */
function handle_categories($method, $parts, $params, $body) {
    global $conn;
    
    // Check if we're dealing with a specific category
    $category_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    switch ($method) {
        case 'GET':
            if ($category_id) {
                // Get specific category
                $sql = "SELECT * FROM kategori WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $category_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    send_response(404, 'Category not found');
                }
                
                $category = $result->fetch_assoc();
                send_response(200, 'Category retrieved successfully', $category);
            } else {
                // List all categories
                $sql = "SELECT * FROM kategori ORDER BY nama ASC";
                $result = $conn->query($sql);
                $categories = [];
                
                while ($row = $result->fetch_assoc()) {
                    $categories[] = $row;
                }
                
                send_response(200, 'Categories retrieved successfully', $categories);
            }
            break;
            
        case 'POST':
            // Create new category - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            // Validate required fields
            $required_fields = ['nama', 'icon'];
            foreach ($required_fields as $field) {
                if (!isset($body[$field]) || empty($body[$field])) {
                    send_response(400, "Missing required field: $field");
                }
            }
            
            // Generate slug from name
            $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['nama'])));
            
            // Check if slug already exists
            $check_sql = "SELECT id FROM kategori WHERE slug = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("s", $slug);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                // Append a random string to make slug unique
                $slug .= '-' . substr(md5(uniqid()), 0, 6);
            }
            
            // Insert category
            $sql = "INSERT INTO kategori (nama, slug, icon) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $body['nama'], $slug, $body['icon']);
            
            if ($stmt->execute()) {
                $new_id = $stmt->insert_id;
                send_response(201, 'Category created successfully', ['id' => $new_id, 'slug' => $slug]);
            } else {
                send_response(500, 'Failed to create category: ' . $stmt->error);
            }
            break;
            
        case 'PUT':
            // Update existing category - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$category_id) {
                send_response(400, 'Category ID is required');
            }
            
            // Check if category exists
            $check_sql = "SELECT id FROM kategori WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $category_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Category not found');
            }
            
            // Build update query based on provided fields
            $update_fields = [];
            $bind_types = "";
            $bind_params = [];
            
            if (isset($body['nama']) && !empty($body['nama'])) {
                $update_fields[] = "nama = ?";
                $bind_types .= "s";
                $bind_params[] = $body['nama'];
                
                // Update slug if name changes
                $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['nama'])));
                $update_fields[] = "slug = ?";
                $bind_types .= "s";
                $bind_params[] = $slug;
            }
            
            if (isset($body['icon']) && !empty($body['icon'])) {
                $update_fields[] = "icon = ?";
                $bind_types .= "s";
                $bind_params[] = $body['icon'];
            }
            
            if (empty($update_fields)) {
                send_response(400, 'No fields to update');
            }
            
            // Add category ID to bind parameters
            $bind_types .= "i";
            $bind_params[] = $category_id;
            
            // Execute update
            $sql = "UPDATE kategori SET " . implode(", ", $update_fields) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($bind_types, ...$bind_params);
            
            if ($stmt->execute()) {
                send_response(200, 'Category updated successfully');
            } else {
                send_response(500, 'Failed to update category: ' . $stmt->error);
            }
            break;
            
        case 'DELETE':
            // Delete category - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$category_id) {
                send_response(400, 'Category ID is required');
            }
            
            // Check if category exists
            $check_sql = "SELECT id FROM kategori WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $category_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Category not found');
            }
            
            // Check if category is used in any articles
            $check_sql = "SELECT COUNT(*) as count FROM artikel WHERE kategori_id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $category_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $count = $check_result->fetch_assoc()['count'];
            
            if ($count > 0) {
                send_response(400, 'Cannot delete category: it is used by ' . $count . ' article(s)');
            }
            
            // Delete category
            $sql = "DELETE FROM kategori WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $category_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Category deleted successfully');
            } else {
                send_response(500, 'Failed to delete category: ' . $stmt->error);
            }
            break;
            
        default:
            send_response(405, 'Method not allowed');
    }
}

/**
 * Handle comment endpoints
 */
function handle_comments($method, $parts, $params, $body) {
    global $conn;
    
    // Check if we're dealing with a specific comment
    $comment_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    switch ($method) {
        case 'GET':
            if ($comment_id) {
                // Get specific comment
                $sql = "SELECT * FROM komentar WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $comment_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    send_response(404, 'Comment not found');
                }
                
                $comment = $result->fetch_assoc();
                send_response(200, 'Comment retrieved successfully', $comment);
            } else {
                // List comments with pagination and filtering
                $page = isset($params['page']) ? (int)$params['page'] : 1;
                $limit = isset($params['limit']) ? (int)$params['limit'] : 20;
                $offset = ($page - 1) * $limit;
                
                // Add article filter if provided
                $article_filter = "";
                $status_filter = "";
                $bind_types = "";
                $bind_params = [];
                
                if (isset($params['artikel_id']) && is_numeric($params['artikel_id'])) {
                    $article_filter = "WHERE artikel_id = ?";
                    $bind_types = "i";
                    $bind_params[] = (int)$params['artikel_id'];
                }
                
                // Add status filter if provided and API key is valid
                if (isset($params['status']) && validate_api_key()) {
                    $status = (int)$params['status'];
                    if (!empty($article_filter)) {
                        $status_filter = " AND status = ?";
                    } else {
                        $status_filter = "WHERE status = ?";
                    }
                    $bind_types .= "i";
                    $bind_params[] = $status;
                } else if (!validate_api_key()) {
                    // If not authenticated, only show approved comments
                    if (!empty($article_filter)) {
                        $status_filter = " AND status = 1";
                    } else {
                        $status_filter = "WHERE status = 1";
                    }
                }
                
                // Get total count for pagination
                $count_sql = "SELECT COUNT(*) as total FROM komentar $article_filter $status_filter";
                $count_stmt = $conn->prepare($count_sql);
                
                if (!empty($bind_types)) {
                    $count_stmt->bind_param($bind_types, ...$bind_params);
                }
                
                $count_stmt->execute();
                $count_result = $count_stmt->get_result();
                $total = $count_result->fetch_assoc()['total'];
                
                // Get comments
                $sql = "SELECT * FROM komentar $article_filter $status_filter ORDER BY created_at DESC LIMIT ?, ?";
                
                $stmt = $conn->prepare($sql);
                $bind_types .= "ii";
                $bind_params[] = $offset;
                $bind_params[] = $limit;
                
                $stmt->bind_param($bind_types, ...$bind_params);
                $stmt->execute();
                $result = $stmt->get_result();
                
                $comments = [];
                while ($row = $result->fetch_assoc()) {
                    $comments[] = $row;
                }
                
                $pagination = [
                    'total' => (int)$total,
                    'page' => $page,
                    'limit' => $limit,
                    'total_pages' => ceil($total / $limit)
                ];
                
                send_response(200, 'Comments retrieved successfully', [
                    'comments' => $comments,
                    'pagination' => $pagination
                ]);
            }
            break;
            
        case 'POST':
            // Create new comment
            // Validate required fields
            $required_fields = ['artikel_id', 'nama', 'email', 'isi'];
            foreach ($required_fields as $field) {
                if (!isset($body[$field]) || empty($body[$field])) {
                    send_response(400, "Missing required field: $field");
                }
            }
            
            // Validate email
            if (!filter_var($body['email'], FILTER_VALIDATE_EMAIL)) {
                send_response(400, 'Invalid email address');
            }
            
            // Check if article exists
            $check_sql = "SELECT id FROM artikel WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $body['artikel_id']);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Article not found');
            }
            
            // Set status based on authentication
            $status = validate_api_key() ? 1 : 0; // Auto-approve if authenticated
            
            // Insert comment
            $sql = "INSERT INTO komentar (artikel_id, nama, email, isi, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isssi", $body['artikel_id'], $body['nama'], $body['email'], $body['isi'], $status);
            
            if ($stmt->execute()) {
                $new_id = $stmt->insert_id;
                send_response(201, 'Comment submitted successfully' . ($status ? '' : ' and awaiting approval'), ['id' => $new_id]);
            } else {
                send_response(500, 'Failed to submit comment: ' . $stmt->error);
            }
            break;
            
        case 'PUT':
            // Update comment status - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$comment_id) {
                send_response(400, 'Comment ID is required');
            }
            
            // Check if comment exists
            $check_sql = "SELECT id FROM komentar WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $comment_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Comment not found');
            }
            
            // Validate required fields
            if (!isset($body['status']) || !in_array((int)$body['status'], [0, 1])) {
                send_response(400, 'Valid status (0 or 1) is required');
            }
            
            // Update comment status
            $status = (int)$body['status'];
            $sql = "UPDATE komentar SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $status, $comment_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Comment status updated successfully');
            } else {
                send_response(500, 'Failed to update comment status: ' . $stmt->error);
            }
            break;
            
        case 'DELETE':
            // Delete comment - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$comment_id) {
                send_response(400, 'Comment ID is required');
            }
            
            // Check if comment exists
            $check_sql = "SELECT id FROM komentar WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $comment_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Comment not found');
            }
            
            // Delete comment
            $sql = "DELETE FROM komentar WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $comment_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Comment deleted successfully');
            } else {
                send_response(500, 'Failed to delete comment: ' . $stmt->error);
            }
            break;
            
        default:
            send_response(405, 'Method not allowed');
    }
}

/**
 * Handle article endpoints
 */
function handle_articles($method, $parts, $params, $body) {
    global $conn;
    
    // Check if we're dealing with a specific article
    $article_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    switch ($method) {
        case 'GET':
            if ($article_id) {
                // Get specific article
                $sql = "SELECT a.*, k.nama as kategori_nama 
                        FROM artikel a 
                        JOIN kategori k ON a.kategori_id = k.id 
                        WHERE a.id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $article_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    send_response(404, 'Article not found');
                }
                
                $article = $result->fetch_assoc();
                
                // Record view for analytics
                record_article_view($article_id);
                
                send_response(200, 'Article retrieved successfully', $article);
            } else {
                // List articles with pagination
                $page = isset($params['page']) ? (int)$params['page'] : 1;
                $limit = isset($params['limit']) ? (int)$params['limit'] : 10;
                $offset = ($page - 1) * $limit;
                
                // Add category filter if provided
                $category_filter = "";
                $bind_types = "";
                $bind_params = [];
                
                if (isset($params['category_id']) && is_numeric($params['category_id'])) {
                    $category_filter = "WHERE a.kategori_id = ?";
                    $bind_types = "i";
                    $bind_params[] = (int)$params['category_id'];
                } else if (isset($params['category_slug']) && !empty($params['category_slug'])) {
                    $category_filter = "WHERE k.slug = ?";
                    $bind_types = "s";
                    $bind_params[] = $params['category_slug'];
                }
                
                // Get total count for pagination
                $count_sql = "SELECT COUNT(*) as total 
                             FROM artikel a 
                             JOIN kategori k ON a.kategori_id = k.id 
                             $category_filter";
                $count_stmt = $conn->prepare($count_sql);
                
                if (!empty($bind_types)) {
                    $count_stmt->bind_param($bind_types, ...$bind_params);
                }
                
                $count_stmt->execute();
                $count_result = $count_stmt->get_result();
                $total = $count_result->fetch_assoc()['total'];
                
                // Get articles
                $sql = "SELECT a.*, k.nama as kategori_nama, k.slug as kategori_slug 
                       FROM artikel a 
                       JOIN kategori k ON a.kategori_id = k.id 
                       $category_filter 
                       ORDER BY a.created_at DESC 
                       LIMIT ?, ?";
                
                $stmt = $conn->prepare($sql);
                $bind_types .= "ii";
                $bind_params[] = $offset;
                $bind_params[] = $limit;
                
                $stmt->bind_param($bind_types, ...$bind_params);
                $stmt->execute();
                $result = $stmt->get_result();
                
                $articles = [];
                while ($row = $result->fetch_assoc()) {
                    $articles[] = $row;
                }
                
                $pagination = [
                    'total' => (int)$total,
                    'page' => $page,
                    'limit' => $limit,
                    'total_pages' => ceil($total / $limit)
                ];
                
                send_response(200, 'Articles retrieved successfully', [
                    'articles' => $articles,
                    'pagination' => $pagination
                ]);
            }
            break;
            
        case 'POST':
            // Create new article - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            // Validate required fields
            $required_fields = ['judul', 'konten', 'kategori_id'];
            foreach ($required_fields as $field) {
                if (!isset($body[$field]) || empty($body[$field])) {
                    send_response(400, "Missing required field: $field");
                }
            }
            
            // Check if category exists
            $check_sql = "SELECT id FROM kategori WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $body['kategori_id']);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Category not found');
            }
            
            // Generate slug from title
            $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['judul'])));
            
            // Check if slug already exists
            $check_sql = "SELECT id FROM artikel WHERE slug = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("s", $slug);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                // Append a random string to make slug unique
                $slug .= '-' . substr(md5(uniqid()), 0, 6);
            }
            
            // Set default values for optional fields
            $gambar = isset($body['gambar']) ? $body['gambar'] : null;
            $meta_description = isset($body['meta_description']) ? $body['meta_description'] : null;
            
            // Insert article
            $sql = "INSERT INTO artikel (judul, slug, konten, kategori_id, gambar, meta_description) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssiss", $body['judul'], $slug, $body['konten'], $body['kategori_id'], $gambar, $meta_description);
            
            if ($stmt->execute()) {
                $new_id = $stmt->insert_id;
                send_response(201, 'Article created successfully', ['id' => $new_id, 'slug' => $slug]);
            } else {
                send_response(500, 'Failed to create article: ' . $stmt->error);
            }
            break;
            
        case 'PUT':
            // Update existing article - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$article_id) {
                send_response(400, 'Article ID is required');
            }
            
            // Check if article exists
            $check_sql = "SELECT id FROM artikel WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $article_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Article not found');
            }
            
            // Build update query based on provided fields
            $update_fields = [];
            $bind_types = "";
            $bind_params = [];
            
            if (isset($body['judul']) && !empty($body['judul'])) {
                $update_fields[] = "judul = ?";
                $bind_types .= "s";
                $bind_params[] = $body['judul'];
                
                // Update slug if title changes
                $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['judul'])));
                $update_fields[] = "slug = ?";
                $bind_types .= "s";
                $bind_params[] = $slug;
            }
            
            if (isset($body['konten'])) {
                $update_fields[] = "konten = ?";
                $bind_types .= "s";
                $bind_params[] = $body['konten'];
            }
            
            if (isset($body['kategori_id']) && is_numeric($body['kategori_id'])) {
                // Check if category exists
                $cat_check_sql = "SELECT id FROM kategori WHERE id = ?";
                $cat_check_stmt = $conn->prepare($cat_check_sql);
                $cat_check_stmt->bind_param("i", $body['kategori_id']);
                $cat_check_stmt->execute();
                $cat_check_result = $cat_check_stmt->get_result();
                
                if ($cat_check_result->num_rows === 0) {
                    send_response(404, 'Category not found');
                }
                
                $update_fields[] = "kategori_id = ?";
                $bind_types .= "i";
                $bind_params[] = $body['kategori_id'];
            }
            
            if (isset($body['gambar'])) {
                $update_fields[] = "gambar = ?";
                $bind_types .= "s";
                $bind_params[] = $body['gambar'];
            }
            
            if (isset($body['meta_description'])) {
                $update_fields[] = "meta_description = ?";
                $bind_types .= "s";
                $bind_params[] = $body['meta_description'];
            }
            
            if (empty($update_fields)) {
                send_response(400, 'No fields to update');
            }
            
            // Add article ID to bind parameters
            $bind_types .= "i";
            $bind_params[] = $article_id;
            
            // Execute update
            $sql = "UPDATE artikel SET " . implode(", ", $update_fields) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($bind_types, ...$bind_params);
            
            if ($stmt->execute()) {
                send_response(200, 'Article updated successfully');
            } else {
                send_response(500, 'Failed to update article: ' . $stmt->error);
            }
            break;
            
        case 'DELETE':
            // Delete article - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$article_id) {
                send_response(400, 'Article ID is required');
            }
            
            // Check if article exists
            $check_sql = "SELECT id FROM artikel WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $article_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Article not found');
            }
            
            // Delete article
            $sql = "DELETE FROM artikel WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $article_id);
            
            if ($stmt->execute()) {
                // Also delete related comments
                $delete_comments_sql = "DELETE FROM komentar WHERE artikel_id = ?";
                $delete_comments_stmt = $conn->prepare($delete_comments_sql);
                $delete_comments_stmt->bind_param("i", $article_id);
                $delete_comments_stmt->execute();
                
                send_response(200, 'Article deleted successfully');
            } else {
                send_response(500, 'Failed to delete article: ' . $stmt->error);
            }
            break;
            
        default:
            send_response(405, 'Method not allowed');
    }
}

/**
 * Handle stats endpoints
 */
function handle_stats($method, $parts, $params, $body) {
    global $conn;
    
    // All stats endpoints require authentication
    if (!validate_api_key()) {
        send_response(401, 'Unauthorized');
    }
    
    $stat_type = isset($parts[1]) ? $parts[1] : null;
    
    switch ($stat_type) {
        case 'popular':
            // Get most popular articles
            $limit = isset($params['limit']) ? (int)$params['limit'] : 5;
            
            $sql = "SELECT a.id, a.judul, a.slug, COUNT(v.id) as view_count 
                   FROM artikel a 
                   LEFT JOIN artikel_views v ON a.id = v.artikel_id 
                   GROUP BY a.id 
                   ORDER BY view_count DESC 
                   LIMIT ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $limit);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $articles = [];
            while ($row = $result->fetch_assoc()) {
                $articles[] = $row;
            }
            
            send_response(200, 'Popular articles retrieved successfully', $articles);
            break;
            
        case 'recent':
            // Get most recent articles
            $limit = isset($params['limit']) ? (int)$params['limit'] : 5;
            
            $sql = "SELECT a.id, a.judul, a.slug, a.created_at 
                   FROM artikel a 
                   ORDER BY a.created_at DESC 
                   LIMIT ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $limit);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $articles = [];
            while ($row = $result->fetch_assoc()) {
                $articles[] = $row;
            }
            
            send_response(200, 'Recent articles retrieved successfully', $articles);
            break;
            
        case 'category-counts':
            // Get article counts by category
            $sql = "SELECT k.id, k.nama, k.slug, COUNT(a.id) as article_count 
                   FROM kategori k 
                   LEFT JOIN artikel a ON k.id = a.kategori_id 
                   GROUP BY k.id 
                   ORDER BY article_count DESC";
            $result = $conn->query($sql);
            
            $categories = [];
            while ($row = $result->fetch_assoc()) {
                $categories[] = $row;
            }
            
            send_response(200, 'Category counts retrieved successfully', $categories);
            break;
            
        default:
            send_response(404, 'Stat type not found');
    }
}