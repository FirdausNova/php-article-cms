<?php
/**
 * API System
 * This file serves as the entry point for the RESTful API
 */

// Set headers for JSON API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Include necessary files
require_once '../config/database.php';
require_once '../config/roles.php';
require_once '../config/analytics.php';

// Get request method and endpoint
$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];

// Parse the URI to get the endpoint and parameters
$uri_parts = parse_url($request_uri);
$path = $uri_parts['path'];

// Remove base path to get the endpoint
$base_path = '/artikel/api/';
$endpoint = str_replace($base_path, '', $path);
$endpoint_parts = explode('/', $endpoint);

// Get query parameters
$params = [];
if (isset($uri_parts['query'])) {
    parse_str($uri_parts['query'], $params);
}

// Get request body for POST, PUT requests
$body = [];
if ($method === 'POST' || $method === 'PUT') {
    $input = file_get_contents('php://input');
    if (!empty($input)) {
        $body = json_decode($input, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            send_response(400, 'Invalid JSON payload');
        }
    }
}

// API Key validation (simple implementation)
function validate_api_key() {
    $headers = getallheaders();
    $api_key = isset($headers['X-API-Key']) ? $headers['X-API-Key'] : null;
    
    // In a real application, you would validate this against a database of valid keys
    // For now, we'll use a simple hardcoded key for demonstration
    $valid_key = 'artikel_api_key_123';
    
    return $api_key === $valid_key;
}

// Send JSON response
function send_response($status_code, $message, $data = null) {
    http_response_code($status_code);
    $response = [
        'status' => $status_code,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

// Route the request to the appropriate handler
switch ($endpoint_parts[0]) {
    case 'articles':
        handle_articles($method, $endpoint_parts, $params, $body);
        break;
    case 'categories':
        handle_categories($method, $endpoint_parts, $params, $body);
        break;
    case 'comments':
        handle_comments($method, $endpoint_parts, $params, $body);
        break;
    case 'stats':
        handle_stats($method, $endpoint_parts, $params, $body);
        break;
    case 'search':
        handle_search($method, $params);
        break;
    default:
        send_response(404, 'Endpoint not found');
}

/**
 * Handle article endpoints
 */
function handle_articles($method, $parts, $params, $body) {
    global $conn;
    
    // Check if we're dealing with a specific article
    $article_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    switch ($method) {
        case 'GET':
            if ($article_id) {
                // Get specific article
                $sql = "SELECT a.*, k.nama as kategori_nama 
                        FROM artikel a 
                        JOIN kategori k ON a.kategori_id = k.id 
                        WHERE a.id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $article_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    send_response(404, 'Article not found');
                }
                
                $article = $result->fetch_assoc();
                
                // Record view for analytics
                record_article_view($article_id);
                
                send_response(200, 'Article retrieved successfully', $article);
            } else {
                // List articles with pagination
                $page = isset($params['page']) ? (int)$params['page'] : 1;
                $limit = isset($params['limit']) ? (int)$params['limit'] : 10;
                $offset = ($page - 1) * $limit;
                
                // Add category filter if provided
                $category_filter = "";
                $bind_types = "";
                $bind_params = [];
                
                if (isset($params['category_id']) && is_numeric($params['category_id'])) {
                    $category_filter = "WHERE a.kategori_id = ?";
                    $bind_types = "i";
                    $bind_params[] = (int)$params['category_id'];
                } else if (isset($params['category_slug']) && !empty($params['category_slug'])) {
                    $category_filter = "WHERE k.slug = ?";
                    $bind_types = "s";
                    $bind_params[] = $params['category_slug'];
                }
                
                // Get total count for pagination
                $count_sql = "SELECT COUNT(*) as total FROM artikel a 
                             JOIN kategori k ON a.kategori_id = k.id 
                             $category_filter";
                $count_stmt = $conn->prepare($count_sql);
                
                if (!empty($bind_types)) {
                    $count_stmt->bind_param($bind_types, ...$bind_params);
                }
                
                $count_stmt->execute();
                $count_result = $count_stmt->get_result();
                $total = $count_result->fetch_assoc()['total'];
                
                // Get articles
                $sql = "SELECT a.id, a.judul, a.slug, a.gambar, a.tanggal_publikasi, k.nama as kategori_nama 
                        FROM artikel a 
                        JOIN kategori k ON a.kategori_id = k.id 
                        $category_filter 
                        ORDER BY a.tanggal_publikasi DESC 
                        LIMIT ?, ?";
                
                $stmt = $conn->prepare($sql);
                $bind_types .= "ii";
                $bind_params[] = $offset;
                $bind_params[] = $limit;
                
                $stmt->bind_param($bind_types, ...$bind_params);
                $stmt->execute();
                $result = $stmt->get_result();
                
                $articles = [];
                while ($row = $result->fetch_assoc()) {
                    $articles[] = $row;
                }
                
                $pagination = [
                    'total' => (int)$total,
                    'page' => $page,
                    'limit' => $limit,
                    'total_pages' => ceil($total / $limit)
                ];
                
                send_response(200, 'Articles retrieved successfully', [
                    'articles' => $articles,
                    'pagination' => $pagination
                ]);
            }
            break;
            
        case 'POST':
            // Create new article - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            // Validate required fields
            $required_fields = ['judul', 'konten', 'kategori_id'];
            foreach ($required_fields as $field) {
                if (!isset($body[$field]) || empty($body[$field])) {
                    send_response(400, "Missing required field: $field");
                }
            }
            
            // Generate slug from title
            $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['judul'])));
            
            // Check if slug already exists
            $check_sql = "SELECT id FROM artikel WHERE slug = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("s", $slug);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                // Append a random string to make slug unique
                $slug .= '-' . substr(md5(uniqid()), 0, 6);
            }
            
            // Set default values for optional fields
            $gambar = isset($body['gambar']) ? $body['gambar'] : 'default.jpg';
            $status = isset($body['status']) ? (int)$body['status'] : 1;
            $tanggal = isset($body['tanggal_publikasi']) ? $body['tanggal_publikasi'] : date('Y-m-d H:i:s');
            
            // Insert article
            $sql = "INSERT INTO artikel (judul, slug, konten, kategori_id, gambar, status, tanggal_publikasi) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssisis", $body['judul'], $slug, $body['konten'], $body['kategori_id'], 
                             $gambar, $status, $tanggal);
            
            if ($stmt->execute()) {
                $new_id = $stmt->insert_id;
                send_response(201, 'Article created successfully', ['id' => $new_id, 'slug' => $slug]);
            } else {
                send_response(500, 'Failed to create article: ' . $stmt->error);
            }
            break;
            
        case 'PUT':
            // Update existing article - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$article_id) {
                send_response(400, 'Article ID is required');
            }
            
            // Check if article exists
            $check_sql = "SELECT id FROM artikel WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $article_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Article not found');
            }
            
            // Build update query based on provided fields
            $update_fields = [];
            $bind_types = "";
            $bind_params = [];
            
            if (isset($body['judul']) && !empty($body['judul'])) {
                $update_fields[] = "judul = ?";
                $bind_types .= "s";
                $bind_params[] = $body['judul'];
                
                // Update slug if title changes
                $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['judul'])));
                $update_fields[] = "slug = ?";
                $bind_types .= "s";
                $bind_params[] = $slug;
            }
            
            if (isset($body['konten'])) {
                $update_fields[] = "konten = ?";
                $bind_types .= "s";
                $bind_params[] = $body['konten'];
            }
            
            if (isset($body['kategori_id']) && is_numeric($body['kategori_id'])) {
                $update_fields[] = "kategori_id = ?";
                $bind_types .= "i";
                $bind_params[] = (int)$body['kategori_id'];
            }
            
            if (isset($body['gambar'])) {
                $update_fields[] = "gambar = ?";
                $bind_types .= "s";
                $bind_params[] = $body['gambar'];
            }
            
            if (isset($body['status']) && in_array((int)$body['status'], [0, 1])) {
                $update_fields[] = "status = ?";
                $bind_types .= "i";
                $bind_params[] = (int)$body['status'];
            }
            
            if (empty($update_fields)) {
                send_response(400, 'No fields to update');
            }
            
            // Add article ID to bind parameters
            $bind_types .= "i";
            $bind_params[] = $article_id;
            
            // Execute update
            $sql = "UPDATE artikel SET " . implode(", ", $update_fields) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($bind_types, ...$bind_params);
            
            if ($stmt->execute()) {
                send_response(200, 'Article updated successfully');
            } else {
                send_response(500, 'Failed to update article: ' . $stmt->error);
            }
            break;
            
        case 'DELETE':
            // Delete article - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$article_id) {
                send_response(400, 'Article ID is required');
            }
            
            // Check if article exists
            $check_sql = "SELECT id FROM artikel WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $article_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Article not found');
            }
            
            // Delete article
            $sql = "DELETE FROM artikel WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $article_id);
            
            if ($stmt->execute()) {
                // Also delete related comments if any
                $delete_comments_sql = "DELETE FROM komentar WHERE artikel_id = ?";
                $delete_comments_stmt = $conn->prepare($delete_comments_sql);
                $delete_comments_stmt->bind_param("i", $article_id);
                $delete_comments_stmt->execute();
                
                send_response(200, 'Article deleted successfully');
            } else {
                send_response(500, 'Failed to delete article: ' . $stmt->error);
            }
            break;
    }
}

/**
 * Handle category endpoints
 */
function handle_categories($method, $parts, $params, $body) {
    global $conn;
    
    // Check if we're dealing with a specific category
    $category_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    switch ($method) {
        case 'GET':
            if ($category_id) {
                // Get specific category
                $sql = "SELECT * FROM kategori WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $category_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    send_response(404, 'Category not found');
                }
                
                $category = $result->fetch_assoc();
                send_response(200, 'Category retrieved successfully', $category);
            } else {
                // List all categories
                $sql = "SELECT * FROM kategori ORDER BY nama ASC";
                $result = $conn->query($sql);
                
                $categories = [];
                while ($row = $result->fetch_assoc()) {
                    $categories[] = $row;
                }
                
                send_response(200, 'Categories retrieved successfully', $categories);
            }
            break;
            
        case 'POST':
            // Create new category - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            // Validate required fields
            if (!isset($body['nama']) || empty($body['nama'])) {
                send_response(400, "Missing required field: nama");
            }
            
            // Generate slug from name
            $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['nama'])));
            
            // Check if slug already exists
            $check_sql = "SELECT id FROM kategori WHERE slug = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("s", $slug);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                // Append a random string to make slug unique
                $slug .= '-' . substr(md5(uniqid()), 0, 6);
            }
            
            // Insert category
            $sql = "INSERT INTO kategori (nama, slug) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $body['nama'], $slug);
            
            if ($stmt->execute()) {
                $new_id = $stmt->insert_id;
                send_response(201, 'Category created successfully', ['id' => $new_id, 'slug' => $slug]);
            } else {
                send_response(500, 'Failed to create category: ' . $stmt->error);
            }
            break;
            
        case 'PUT':
            // Update existing category - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$category_id) {
                send_response(400, 'Category ID is required');
            }
            
            // Check if category exists
            $check_sql = "SELECT id FROM kategori WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $category_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Category not found');
            }
            
            // Update category name and slug
            if (!isset($body['nama']) || empty($body['nama'])) {
                send_response(400, "Missing required field: nama");
            }
            
            // Generate slug from name
            $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\-]/', '', $body['nama'])));
            
            // Check if slug already exists for other categories
            $check_sql = "SELECT id FROM kategori WHERE slug = ? AND id != ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("si", $slug, $category_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                // Append a random string to make slug unique
                $slug .= '-' . substr(md5(uniqid()), 0, 6);
            }
            
            // Update category
            $sql = "UPDATE kategori SET nama = ?, slug = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $body['nama'], $slug, $category_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Category updated successfully');
            } else {
                send_response(500, 'Failed to update category: ' . $stmt->error);
            }
            break;
            
        case 'DELETE':
            // Delete category - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$category_id) {
                send_response(400, 'Category ID is required');
            }
            
            // Check if category exists
            $check_sql = "SELECT id FROM kategori WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $category_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Category not found');
            }
            
            // Check if category is used in any article
            $check_articles_sql = "SELECT COUNT(*) as count FROM artikel WHERE kategori_id = ?";
            $check_articles_stmt = $conn->prepare($check_articles_sql);
            $check_articles_stmt->bind_param("i", $category_id);
            $check_articles_stmt->execute();
            $check_articles_result = $check_articles_stmt->get_result();
            $article_count = $check_articles_result->fetch_assoc()['count'];
            
            if ($article_count > 0) {
                send_response(400, 'Cannot delete category: it is used by ' . $article_count . ' article(s)');
            }
            
            // Delete category
            $sql = "DELETE FROM kategori WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $category_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Category deleted successfully');
            } else {
                send_response(500, 'Failed to delete category: ' . $stmt->error);
            }
            break;
    }
}

/**
 * Handle comment endpoints
 */
function handle_comments($method, $parts, $params, $body) {
    global $conn;
    
    // Check if we're dealing with a specific comment
    $comment_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    
    switch ($method) {
        case 'GET':
            if ($comment_id) {
                // Get specific comment
                $sql = "SELECT * FROM komentar WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $comment_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    send_response(404, 'Comment not found');
            }
            
            // Only allow updating status
            if (!isset($body['status']) || !in_array((int)$body['status'], [0, 1, 2])) {
                send_response(400, "Missing or invalid status field");
            }
            
            // Update comment status
            $sql = "UPDATE komentar SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $body['status'], $comment_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Comment status updated successfully');
            } else {
                send_response(500, 'Failed to update comment status: ' . $stmt->error);
            }
            break;
            
        case 'DELETE': {
            // Delete comment - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$comment_id) {
                send_response(400, 'Comment ID is required');
            }
            
            // Check if comment exists
            $check_sql = "SELECT id FROM komentar WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $comment_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Comment not found');
            }
            
            // Delete comment
            $sql = "DELETE FROM komentar WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $comment_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Comment deleted successfully');
            } else {
                send_response(500, 'Failed to delete comment: ' . $stmt->error);
            }
            break;
    }
}

/**
 * Handle stats endpoints
 */
function handle_stats($method, $parts, $params, $body) {
    global $conn;
    
    // Only GET method is allowed for stats
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Check which stat is requested
    $stat_type = isset($parts[1]) ? $parts[1] : 'overview';
    
    switch ($stat_type) {
        case 'overview':
            // Get general stats
            $stats = [];
            
            // Count total articles
            $articles_sql = "SELECT COUNT(*) as count FROM artikel";
            $result = $conn->query($articles_sql);
            $stats['total_articles'] = (int)$result->fetch_assoc()['count'];
            
            // Count total categories
            $categories_sql = "SELECT COUNT(*) as count FROM kategori";
            $result = $conn->query($categories_sql);
            $stats['total_categories'] = (int)$result->fetch_assoc()['count'];
            
            // Count total comments
            $comments_sql = "SELECT COUNT(*) as count FROM komentar";
            $result = $conn->query($comments_sql);
            $stats['total_comments'] = (int)$result->fetch_assoc()['count'];
            
            // Count approved comments
            $approved_comments_sql = "SELECT COUNT(*) as count FROM komentar WHERE status = 1";
            $result = $conn->query($approved_comments_sql);
            $stats['approved_comments'] = (int)$result->fetch_assoc()['count'];
            
            // Get most viewed articles
            $popular_sql = "SELECT a.id, a.judul, a.slug, COUNT(v.id) as view_count 
                           FROM artikel a 
                           LEFT JOIN artikel_views v ON a.id = v.artikel_id 
                           GROUP BY a.id 
                           ORDER BY view_count DESC 
                           LIMIT 5";
            $result = $conn->query($popular_sql);
            $popular_articles = [];
            while ($row = $result->fetch_assoc()) {
                $popular_articles[] = $row;
            }
            $stats['popular_articles'] = $popular_articles;
            
            send_response(200, 'Stats retrieved successfully', $stats);
            break;
            
        case 'views':
            // Get view statistics with optional date filtering
            $date_filter = "";
            $bind_types = "";
            $bind_params = [];
            
            if (isset($params['start_date']) && !empty($params['start_date'])) {
                $date_filter .= " AND v.tanggal >= ?";
                $bind_types .= "s";
                $bind_params[] = $params['start_date'];
            }
            
            if (isset($params['end_date']) && !empty($params['end_date'])) {
                $date_filter .= " AND v.tanggal <= ?";
                $bind_types .= "s";
                $bind_params[] = $params['end_date'];
            }
            
            $sql = "SELECT a.id, a.judul, COUNT(v.id) as view_count 
                   FROM artikel a 
                   LEFT JOIN artikel_views v ON a.id = v.artikel_id 
                   WHERE 1=1 $date_filter 
                   GROUP BY a.id 
                   ORDER BY view_count DESC";
            
            $stmt = $conn->prepare($sql);
            
            if (!empty($bind_types)) {
                $stmt->bind_param($bind_types, ...$bind_params);
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            
            $views_data = [];
            while ($row = $result->fetch_assoc()) {
                $views_data[] = $row;
            }
            
            send_response(200, 'View statistics retrieved successfully', $views_data);
            break;
            
        case 'categories':
            // Get category statistics
            $sql = "SELECT k.id, k.nama, COUNT(a.id) as article_count 
                   FROM kategori k 
                   LEFT JOIN artikel a ON k.id = a.kategori_id 
                   GROUP BY k.id 
                   ORDER BY article_count DESC";
            
            $result = $conn->query($sql);
            
            $category_stats = [];
            while ($row = $result->fetch_assoc()) {
                $category_stats[] = $row;
            }
            
            send_response(200, 'Category statistics retrieved successfully', $category_stats);
            break;
            
        default:
            send_response(404, 'Stat type not found');
    }
}

/**
 * Handle search endpoint
 */
function handle_search($method, $params) {
    global $conn;
    
    // Only GET method is allowed for search
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Check if search query is provided
    if (!isset($params['q']) || empty($params['q'])) {
        send_response(400, 'Search query is required');
    }
    
    $search_query = '%' . $params['q'] . '%';
    
    // Pagination parameters
    $page = isset($params['page']) ? (int)$params['page'] : 1;
    $limit = isset($params['limit']) ? (int)$params['limit'] : 10;
    $offset = ($page - 1) * $limit;
    
    // Get total count for pagination
    $count_sql = "SELECT COUNT(*) as total FROM artikel 
                 WHERE judul LIKE ? OR konten LIKE ?";
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("ss", $search_query, $search_query);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total = $count_result->fetch_assoc()['total'];
    
    // Get search results
    $sql = "SELECT a.id, a.judul, a.slug, a.tanggal_publikasi, k.nama as kategori_nama, 
           SUBSTRING(a.konten, 1, 200) as excerpt 
           FROM artikel a 
           JOIN kategori k ON a.kategori_id = k.id 
           WHERE a.judul LIKE ? OR a.konten LIKE ? 
           ORDER BY a.tanggal_publikasi DESC 
           LIMIT ?, ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $search_query, $search_query, $offset, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $search_results = [];
    while ($row = $result->fetch_assoc()) {
        // Add ellipsis to excerpt if content is longer
        if (strlen($row['excerpt']) >= 200) {
            $row['excerpt'] .= '...';
        }
        $search_results[] = $row;
    }
    
    $pagination = [
        'total' => (int)$total,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($total / $limit)
    ];
    
    // Record search query for analytics
    record_search_query($params['q']);
    
    send_response(200, 'Search results retrieved successfully', [
        'results' => $search_results,
        'pagination' => $pagination
    ]);
}

/**
 * Record article view for analytics
 */
function record_article_view($article_id) {
    global $conn;
    
    // Get visitor IP address
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $tanggal = date('Y-m-d H:i:s');
    
    // Insert view record
    $sql = "INSERT INTO artikel_views (artikel_id, ip_address, user_agent, tanggal) 
            VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $article_id, $ip_address, $user_agent, $tanggal);
    $stmt->execute();
}

/**
 * Record search query for analytics
 */
function record_search_query($query) {
    global $conn;
    
    // Get visitor IP address
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $tanggal = date('Y-m-d H:i:s');
    
    // Insert search record
    $sql = "INSERT INTO search_logs (query, ip_address, tanggal) 
            VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $query, $ip_address, $tanggal);
    $stmt->execute();
} found');
                }
                
                $comment = $result->fetch_assoc();
                send_response(200, 'Comment retrieved successfully', $comment);
            } else {
                // List comments with pagination and filtering
                $page = isset($params['page']) ? (int)$params['page'] : 1;
                $limit = isset($params['limit']) ? (int)$params['limit'] : 10;
                $offset = ($page - 1) * $limit;
                
                // Add article filter if provided
                $article_filter = "";
                $bind_types = "";
                $bind_params = [];
                
                if (isset($params['article_id']) && is_numeric($params['article_id'])) {
                    $article_filter = "WHERE artikel_id = ?";
                    $bind_types = "i";
                    $bind_params[] = (int)$params['article_id'];
                }
                
                // Get total count for pagination
                $count_sql = "SELECT COUNT(*) as total FROM komentar $article_filter";
                $count_stmt = $conn->prepare($count_sql);
                
                if (!empty($bind_types)) {
                    $count_stmt->bind_param($bind_types, ...$bind_params);
                }
                
                $count_stmt->execute();
                $count_result = $count_stmt->get_result();
                $total = $count_result->fetch_assoc()['total'];
                
                // Get comments
                $sql = "SELECT * FROM komentar $article_filter ORDER BY tanggal DESC LIMIT ?, ?";
                
                $stmt = $conn->prepare($sql);
                $bind_types .= "ii";
                $bind_params[] = $offset;
                $bind_params[] = $limit;
                
                $stmt->bind_param($bind_types, ...$bind_params);
                $stmt->execute();
                $result = $stmt->get_result();
                
                $comments = [];
                while ($row = $result->fetch_assoc()) {
                    $comments[] = $row;
                }
                
                $pagination = [
                    'total' => (int)$total,
                    'page' => $page,
                    'limit' => $limit,
                    'total_pages' => ceil($total / $limit)
                ];
                
                send_response(200, 'Comments retrieved successfully', [
                    'comments' => $comments,
                    'pagination' => $pagination
                ]);
            }
            break;
            
        case 'POST':
            // Create new comment
            // Validate required fields
            $required_fields = ['artikel_id', 'nama', 'email', 'isi'];
            foreach ($required_fields as $field) {
                if (!isset($body[$field]) || empty($body[$field])) {
                    send_response(400, "Missing required field: $field");
                }
            }
            
            // Validate email format
            if (!filter_var($body['email'], FILTER_VALIDATE_EMAIL)) {
                send_response(400, "Invalid email format");
            }
            
            // Check if article exists
            $check_sql = "SELECT id FROM artikel WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $body['artikel_id']);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Article not found');
            }
            
            // Insert comment
            $status = isset($body['status']) ? (int)$body['status'] : 0; // Default to pending
            $tanggal = date('Y-m-d H:i:s');
            
            $sql = "INSERT INTO komentar (artikel_id, nama, email, isi, status, tanggal) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isssis", $body['artikel_id'], $body['nama'], $body['email'], 
                             $body['isi'], $status, $tanggal);
            
            if ($stmt->execute()) {
                $new_id = $stmt->insert_id;
                send_response(201, 'Comment created successfully', ['id' => $new_id]);
            } else {
                send_response(500, 'Failed to create comment: ' . $stmt->error);
            }
            break;
            
        case 'PUT':
            // Update comment status - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$comment_id) {
                send_response(400, 'Comment ID is required');
            }
            
            // Check if comment exists
            $check_sql = "SELECT id FROM komentar WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $comment_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Comment not found');
            }
            
            // Only allow updating status
            if (!isset($body['status']) || !in_array((int)$body['status'], [0, 1, 2])) {
                send_response(400, "Missing or invalid status field");
            }
            
            // Update comment status
            $sql = "UPDATE komentar SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $body['status'], $comment_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Comment status updated successfully');
            } else {
                send_response(500, 'Failed to update comment status: ' . $stmt->error);
            }
            break;
            
        case 'DELETE':
            // Delete comment - requires authentication
            if (!validate_api_key()) {
                send_response(401, 'Unauthorized');
            }
            
            if (!$comment_id) {
                send_response(400, 'Comment ID is required');
            }
            
            // Check if comment exists
            $check_sql = "SELECT id FROM komentar WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param("i", $comment_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                send_response(404, 'Comment not found');
            }
            
            // Delete comment
            $sql = "DELETE FROM komentar WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $comment_id);
            
            if ($stmt->execute()) {
                send_response(200, 'Comment deleted successfully');
            } else {
                send_response(500, 'Failed to delete comment: ' . $stmt->error);
            }
            break;
    }
}

/**
 * Handle stats endpoints
 */
function handle_stats($method, $parts, $params, $body) {
    global $conn;
    
    // Only GET method is allowed for stats
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Check which stat is requested
    $stat_type = isset($parts[1]) ? $parts[1] : 'overview';
    
    switch ($stat_type) {
        case 'overview':
            // Get general stats
            $stats = [];
            
            // Count total articles
            $articles_sql = "SELECT COUNT(*) as count FROM artikel";
            $result = $conn->query($articles_sql);
            $stats['total_articles'] = (int)$result->fetch_assoc()['count'];
            
            // Count total categories
            $categories_sql = "SELECT COUNT(*) as count FROM kategori";
            $result = $conn->query($categories_sql);
            $stats['total_categories'] = (int)$result->fetch_assoc()['count'];
            
            // Count total comments
            $comments_sql = "SELECT COUNT(*) as count FROM komentar";
            $result = $conn->query($comments_sql);
            $stats['total_comments'] = (int)$result->fetch_assoc()['count'];
            
            // Count approved comments
            $approved_comments_sql = "SELECT COUNT(*) as count FROM komentar WHERE status = 1";
            $result = $conn->query($approved_comments_sql);
            $stats['approved_comments'] = (int)$result->fetch_assoc()['count'];
            
            // Get most viewed articles
            $popular_sql = "SELECT a.id, a.judul, a.slug, COUNT(v.id) as view_count 
                           FROM artikel a 
                           LEFT JOIN artikel_views v ON a.id = v.artikel_id 
                           GROUP BY a.id 
                           ORDER BY view_count DESC 
                           LIMIT 5";
            $result = $conn->query($popular_sql);
            $popular_articles = [];
            while ($row = $result->fetch_assoc()) {
                $popular_articles[] = $row;
            }
            $stats['popular_articles'] = $popular_articles;
            
            send_response(200, 'Stats retrieved successfully', $stats);
            break;
            
        case 'views':
            // Get view statistics with optional date filtering
            $date_filter = "";
            $bind_types = "";
            $bind_params = [];
            
            if (isset($params['start_date']) && !empty($params['start_date'])) {
                $date_filter .= " AND v.tanggal >= ?";
                $bind_types .= "s";
                $bind_params[] = $params['start_date'];
            }
            
            if (isset($params['end_date']) && !empty($params['end_date'])) {
                $date_filter .= " AND v.tanggal <= ?";
                $bind_types .= "s";
                $bind_params[] = $params['end_date'];
            }
            
            $sql = "SELECT a.id, a.judul, COUNT(v.id) as view_count 
                   FROM artikel a 
                   LEFT JOIN artikel_views v ON a.id = v.artikel_id 
                   WHERE 1=1 $date_filter 
                   GROUP BY a.id 
                   ORDER BY view_count DESC";
            
            $stmt = $conn->prepare($sql);
            
            if (!empty($bind_types)) {
                $stmt->bind_param($bind_types, ...$bind_params);
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            
            $views_data = [];
            while ($row = $result->fetch_assoc()) {
                $views_data[] = $row;
            }
            
            send_response(200, 'View statistics retrieved successfully', $views_data);
            break;
            
        case 'categories':
            // Get category statistics
            $sql = "SELECT k.id, k.nama, COUNT(a.id) as article_count 
                   FROM kategori k 
                   LEFT JOIN artikel a ON k.id = a.kategori_id 
                   GROUP BY k.id 
                   ORDER BY article_count DESC";
            
            $result = $conn->query($sql);
            
            $category_stats = [];
            while ($row = $result->fetch_assoc()) {
                $category_stats[] = $row;
            }
            
            send_response(200, 'Category statistics retrieved successfully', $category_stats);
            break;
            
        default:
            send_response(404, 'Stat type not found');
    }
}

/**
 * Handle search endpoint
 */
function handle_search($method, $params) {
    global $conn;
    
    // Only GET method is allowed for search
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Check if search query is provided
    if (!isset($params['q']) || empty($params['q'])) {
        send_response(400, 'Search query is required');
    }
    
    $search_query = '%' . $params['q'] . '%';
    
    // Pagination parameters
    $page = isset($params['page']) ? (int)$params['page'] : 1;
    $limit = isset($params['limit']) ? (int)$params['limit'] : 10;
    $offset = ($page - 1) * $limit;
    
    // Get total count for pagination
    $count_sql = "SELECT COUNT(*) as total FROM artikel 
                 WHERE judul LIKE ? OR konten LIKE ?";
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("ss", $search_query, $search_query);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total = $count_result->fetch_assoc()['total'];
    
    // Get search results
    $sql = "SELECT a.id, a.judul, a.slug, a.tanggal_publikasi, k.nama as kategori_nama, 
           SUBSTRING(a.konten, 1, 200) as excerpt 
           FROM artikel a 
           JOIN kategori k ON a.kategori_id = k.id 
           WHERE a.judul LIKE ? OR a.konten LIKE ? 
           ORDER BY a.tanggal_publikasi DESC 
           LIMIT ?, ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $search_query, $search_query, $offset, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $search_results = [];
    while ($row = $result->fetch_assoc()) {
        // Add ellipsis to excerpt if content is longer
        if (strlen($row['excerpt']) >= 200) {
            $row['excerpt'] .= '...';
        }
        $search_results[] = $row;
    }
    
    $pagination = [
        'total' => (int)$total,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($total / $limit)
    ];
    
    // Record search query for analytics
    record_search_query($params['q']);
    
    send_response(200, 'Search results retrieved successfully', [
        'results' => $search_results,
        'pagination' => $pagination
    ]);
}

/**
 * Record article view for analytics
 */
function record_article_view($article_id) {
    global $conn;
    
    // Get visitor IP address
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $tanggal = date('Y-m-d H:i:s');
    
    // Insert view record
    $sql = "INSERT INTO artikel_views (artikel_id, ip_address, user_agent, tanggal) 
            VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $article_id, $ip_address, $user_agent, $tanggal);
    $stmt->execute();
}

/**
 * Record search query for analytics
 */
function record_search_query($query) {
    global $conn;
    
    // Get visitor IP address
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $tanggal = date('Y-m-d H:i:s');
    
    // Insert search record
    $sql = "INSERT INTO search_logs (query, ip_address, tanggal) 
            VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $query, $ip_address, $tanggal);
    $stmt->execute();
}