<?php
/**
 * API Stats and Search Handlers
 * This file contains handler functions for the stats and search API endpoints
 */

// Include necessary files if not already included
require_once '../config/database.php';
require_once '../config/analytics.php';

/**
 * Handle stats endpoints
 */
function handle_stats($method, $parts, $params, $body) {
    global $conn;
    
    // Stats endpoints require authentication
    if (!validate_api_key()) {
        send_response(401, 'Unauthorized');
    }
    
    // Check if we're dealing with a specific article's stats
    $article_id = isset($parts[1]) && is_numeric($parts[1]) ? (int)$parts[1] : null;
    $stat_type = isset($parts[2]) ? $parts[2] : null;
    
    switch ($method) {
        case 'GET':
            if ($article_id) {
                // Get stats for a specific article
                if ($stat_type === 'views') {
                    // Get view statistics
                    $view_count = get_article_views($article_id);
                    
                    // Get view history by day for the last 30 days
                    $sql = "SELECT DATE(view_date) as date, COUNT(DISTINCT session_id) as views 
                            FROM article_views 
                            WHERE artikel_id = ? AND view_date > DATE_SUB(NOW(), INTERVAL 30 DAY) 
                            GROUP BY DATE(view_date) 
                            ORDER BY date ASC";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $article_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    $view_history = [];
                    while ($row = $result->fetch_assoc()) {
                        $view_history[] = $row;
                    }
                    
                    send_response(200, 'View statistics retrieved successfully', [
                        'total_views' => $view_count,
                        'view_history' => $view_history
                    ]);
                } else if ($stat_type === 'engagement') {
                    // Get engagement statistics
                    $engagement = get_article_engagement($article_id);
                    send_response(200, 'Engagement statistics retrieved successfully', $engagement);
                } else {
                    // Get all stats for the article
                    $view_count = get_article_views($article_id);
                    $engagement = get_article_engagement($article_id);
                    
                    // Get referrer sources
                    $sql = "SELECT referer, COUNT(*) as count 
                            FROM article_views 
                            WHERE artikel_id = ? AND referer IS NOT NULL AND referer != '' 
                            GROUP BY referer 
                            ORDER BY count DESC 
                            LIMIT 10";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $article_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    $referrers = [];
                    while ($row = $result->fetch_assoc()) {
                        $referrers[] = $row;
                    }
                    
                    send_response(200, 'Article statistics retrieved successfully', [
                        'views' => $view_count,
                        'engagement' => $engagement,
                        'referrers' => $referrers
                    ]);
                }
            } else {
                // Get overall site statistics
                
                // Get total views across all articles
                $sql = "SELECT COUNT(DISTINCT session_id) as total_views FROM article_views";
                $result = $conn->query($sql);
                $total_views = $result->fetch_assoc()['total_views'];
                
                // Get popular articles
                $popular_articles = get_popular_articles(10);
                
                // Get trending searches
                $trending_searches = get_trending_searches();
                
                // Get view counts by day for the last 30 days
                $sql = "SELECT DATE(view_date) as date, COUNT(DISTINCT session_id) as views 
                        FROM article_views 
                        WHERE view_date > DATE_SUB(NOW(), INTERVAL 30 DAY) 
                        GROUP BY DATE(view_date) 
                        ORDER BY date ASC";
                $result = $conn->query($sql);
                
                $daily_views = [];
                while ($row = $result->fetch_assoc()) {
                    $daily_views[] = $row;
                }
                
                // Get category distribution
                $sql = "SELECT k.nama as category, COUNT(DISTINCT av.session_id) as views 
                        FROM article_views av 
                        JOIN artikel a ON av.artikel_id = a.id 
                        JOIN kategori k ON a.kategori_id = k.id 
                        GROUP BY k.id 
                        ORDER BY views DESC";
                $result = $conn->query($sql);
                
                $category_views = [];
                while ($row = $result->fetch_assoc()) {
                    $category_views[] = $row;
                }
                
                send_response(200, 'Site statistics retrieved successfully', [
                    'total_views' => $total_views,
                    'popular_articles' => $popular_articles,
                    'trending_searches' => $trending_searches,
                    'daily_views' => $daily_views,
                    'category_views' => $category_views
                ]);
            }
            break;
            
        case 'POST':
            // Record engagement event
            if (!$article_id) {
                send_response(400, 'Article ID is required');
            }
            
            // Validate required fields
            if (!isset($body['engagement_type']) || empty($body['engagement_type'])) {
                send_response(400, 'Engagement type is required');
            }
            
            $engagement_type = $body['engagement_type'];
            $value = isset($body['value']) ? (int)$body['value'] : 1;
            
            // Validate engagement type
            $valid_types = ['like', 'share', 'bookmark', 'time_spent'];
            if (!in_array($engagement_type, $valid_types)) {
                send_response(400, 'Invalid engagement type. Must be one of: ' . implode(', ', $valid_types));
            }
            
            // Record the engagement
            if (record_engagement($article_id, $engagement_type, $value)) {
                send_response(201, 'Engagement recorded successfully');
            } else {
                send_response(500, 'Failed to record engagement');
            }
            break;
            
        default:
            send_response(405, 'Method not allowed');
    }
}

/**
 * Handle search endpoint
 */
function handle_search($method, $params) {
    global $conn;
    
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Validate search query
    if (!isset($params['q']) || empty($params['q'])) {
        send_response(400, 'Search query is required');
    }
    
    $search_query = '%' . $params['q'] . '%';
    $page = isset($params['page']) ? (int)$params['page'] : 1;
    $limit = isset($params['limit']) ? (int)$params['limit'] : 10;
    $offset = ($page - 1) * $limit;
    
    // Add category filter if provided
    $category_filter = "";
    $bind_types = "ss";
    $bind_params = [$search_query, $search_query];
    
    if (isset($params['category']) && !empty($params['category'])) {
        $category_filter = "AND k.slug = ?";
        $bind_types .= "s";
        $bind_params[] = $params['category'];
    }
    
    // Get total count for pagination
    $count_sql = "SELECT COUNT(*) as total 
                 FROM artikel a 
                 JOIN kategori k ON a.kategori_id = k.id 
                 WHERE (a.judul LIKE ? OR a.konten LIKE ?) $category_filter";
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param($bind_types, ...$bind_params);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total = $count_result->fetch_assoc()['total'];
    
    // Get search results
    $sql = "SELECT a.id, a.judul, a.slug, a.gambar, a.tanggal_publikasi, 
                  k.nama as kategori_nama, k.slug as kategori_slug,
                  SUBSTRING(a.konten, 1, 200) as excerpt 
           FROM artikel a 
           JOIN kategori k ON a.kategori_id = k.id 
           WHERE (a.judul LIKE ? OR a.konten LIKE ?) $category_filter 
           ORDER BY a.tanggal_publikasi DESC 
           LIMIT ?, ?";
    
    $stmt = $conn->prepare($sql);
    $bind_types .= "ii";
    $bind_params[] = $offset;
    $bind_params[] = $limit;
    
    // Complete the advanced search function
    $articles = complete_advanced_search($stmt, $bind_types, $bind_params);
    
    // Get facet data for categories
    $facets = [];
    
    // Category facets
    $facet_sql = "SELECT k.id, k.nama, k.slug, COUNT(a.id) as count 
                FROM kategori k
                LEFT JOIN artikel a ON k.id = a.kategori_id
                " . ($where_clause ? $where_clause . " AND a.id IS NOT NULL" : "WHERE a.id IS NOT NULL") . "
                GROUP BY k.id
                ORDER BY count DESC";
                
    $facet_stmt = $conn->prepare($facet_sql);
    
    if (!empty($bind_types)) {
        // We only need the search and filter params, not the pagination ones
        $facet_params = array_slice($bind_params, 0, count($bind_params) - 2);
        if (!empty($facet_params)) {
            $facet_bind_types = substr($bind_types, 0, strlen($bind_types) - 2);
            $facet_stmt->bind_param($facet_bind_types, ...$facet_params);
        }
    }
    
    $facet_stmt->execute();
    $facet_result = $facet_stmt->get_result();
    
    $category_facets = [];
    while ($row = $facet_result->fetch_assoc()) {
        $category_facets[] = $row;
    }
    
    $facets['categories'] = $category_facets;
    
    // Date facets (by month)
    $date_facet_sql = "SELECT 
                        DATE_FORMAT(a.tanggal_publikasi, '%Y-%m') as month,
                        COUNT(a.id) as count
                      FROM artikel a
                      JOIN kategori k ON a.kategori_id = k.id
                      " . ($where_clause ? $where_clause : "") . "
                      GROUP BY month
                      ORDER BY month DESC";
                      
    $date_facet_stmt = $conn->prepare($date_facet_sql);
    
    if (!empty($bind_types) && !empty($facet_params)) {
        $date_facet_stmt->bind_param($facet_bind_types, ...$facet_params);
    }
    
    $date_facet_stmt->execute();
    $date_facet_result = $date_facet_stmt->get_result();
    
    $date_facets = [];
    while ($row = $date_facet_result->fetch_assoc()) {
        $date_facets[] = $row;
    }
    
    $facets['dates'] = $date_facets;
    
    $pagination = [
        'total' => (int)$total,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($total / $limit)
    ];
    
    // Log the search query if provided
    if ($search_query) {
        log_search(str_replace('%', '', $search_query), $total);
    }
    
    send_response(200, 'Advanced search results retrieved successfully', [
        'query' => isset($params['q']) ? $params['q'] : '',
        'results' => $articles,
        'facets' => $facets,
        'pagination' => $pagination,
        'filters' => $params
    ]);
}

/**
 * Log search queries for analytics
 */
function log_search($query, $result_count) {
    global $conn;
    
    $sql = "INSERT INTO search_logs (query, result_count, search_date, ip_address) VALUES (?, ?, NOW(), ?)";
    $stmt = $conn->prepare($sql);
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt->bind_param("sis", $query, $result_count, $ip);
    $stmt->execute();
}

/**
 * Get trending searches
 */
function get_trending_searches($limit = 5) {
    global $conn;
    
    $sql = "SELECT query, COUNT(*) as search_count 
           FROM search_logs 
           WHERE search_date > DATE_SUB(NOW(), INTERVAL 7 DAY) 
           GROUP BY query 
           ORDER BY search_count DESC 
           LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $trending = [];
    while ($row = $result->fetch_assoc()) {
        $trending[] = $row;
    }
    
    return $trending;
}

/**
 * Get popular articles based on view count
 */
function get_popular_articles($limit = 5) {
    global $conn;
    
    $sql = "SELECT a.id, a.judul, a.slug, COUNT(DISTINCT v.session_id) as view_count 
           FROM artikel a 
           JOIN artikel_views v ON a.id = v.artikel_id 
           WHERE v.view_date > DATE_SUB(NOW(), INTERVAL 30 DAY) 
           GROUP BY a.id 
           ORDER BY view_count DESC 
           LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $articles = [];
    while ($row = $result->fetch_assoc()) {
        $articles[] = $row;
    }
    
    return $articles;
}
    
    $stmt->bind_param($bind_types, ...$bind_params);
    $stmt->execute();
    $result = $stmt->get_result();

    
    
    $articles = [];
    while ($row = $result->fetch_assoc()) {
        // Highlight search terms in title and excerpt
        $row['judul'] = preg_replace('/(' . str_replace('%', '', $search_query) . ')/i', '<mark>$1</mark>', $row['judul']);
        $row['excerpt'] = preg_replace('/(' . str_replace('%', '', $search_query) . ')/i', '<mark>$1</mark>', $row['excerpt']);
        $articles[] = $row;
    }
    
    $pagination = [
        'total' => (int)$total,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($total / $limit)
    ];
    
    // Log the search query
    log_search($params['q'], $total);
    
    send_response(200, 'Search results retrieved successfully', [
        'query' => $params['q'],
        'results' => $articles,
        'pagination' => $pagination
    ]);

/**
 * Handle advanced search with filters and facets
 */
function handle_advanced_search($method, $params) {
    global $conn;
    
    if ($method !== 'GET') {
        send_response(405, 'Method not allowed');
    }
    
    // Base search query
    $search_query = isset($params['q']) && !empty($params['q']) ? '%' . $params['q'] . '%' : null;
    $page = isset($params['page']) ? (int)$params['page'] : 1;
    $limit = isset($params['limit']) ? (int)$params['limit'] : 10;
    $offset = ($page - 1) * $limit;
    
    // Build WHERE clause with filters
    $where_clauses = [];
    $bind_types = "";
    $bind_params = [];
    
    // Text search
    if ($search_query) {
        $where_clauses[] = "(a.judul LIKE ? OR a.konten LIKE ?)";
        $bind_types .= "ss";
        $bind_params[] = $search_query;
        $bind_params[] = $search_query;
    }
    
    // Category filter
    if (isset($params['category']) && !empty($params['category'])) {
        $where_clauses[] = "k.slug = ?";
        $bind_types .= "s";
        $bind_params[] = $params['category'];
    }
    
    // Date range filter
    if (isset($params['date_from']) && !empty($params['date_from'])) {
        $where_clauses[] = "a.tanggal_publikasi >= ?";
        $bind_types .= "s";
        $bind_params[] = $params['date_from'];
    }
    
    if (isset($params['date_to']) && !empty($params['date_to'])) {
        $where_clauses[] = "a.tanggal_publikasi <= ?";
        $bind_types .= "s";
        $bind_params[] = $params['date_to'];
    }
    
    // Build the final WHERE clause
    $where_clause = !empty($where_clauses) ? "WHERE " . implode(" AND ", $where_clauses) : "";
    
    // Get total count for pagination
    $count_sql = "SELECT COUNT(*) as total 
                 FROM artikel a 
                 JOIN kategori k ON a.kategori_id = k.id 
                 $where_clause";
    $count_stmt = $conn->prepare($count_sql);
    
    if (!empty($bind_types)) {
        $count_stmt->bind_param($bind_types, ...$bind_params);
    }
    
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total = $count_result->fetch_assoc()['total'];
    
    // Determine sort order
    $sort_field = isset($params['sort']) ? $params['sort'] : 'tanggal_publikasi';
    $sort_dir = isset($params['dir']) && strtolower($params['dir']) === 'asc' ? 'ASC' : 'DESC';
    
    // Validate sort field to prevent SQL injection
    $valid_sort_fields = ['judul', 'tanggal_publikasi', 'created_at'];
    if (!in_array($sort_field, $valid_sort_fields)) {
        $sort_field = 'tanggal_publikasi';
    }
    
    // Get search results
    $sql = "SELECT a.id, a.judul, a.slug, a.gambar, a.tanggal_publikasi, 
                  k.nama as kategori_nama, k.slug as kategori_slug,
                  SUBSTRING(a.konten, 1, 200) as excerpt 
           FROM artikel a 
           JOIN kategori k ON a.kategori_id = k.id 
           $where_clause 
           ORDER BY a.$sort_field $sort_dir 
           LIMIT ?, ?";
    
    $stmt = $conn->prepare($sql);
    $bind_types .= "ii";
    $bind_params[] = $offset;
    $bind_params[] = $limit;
    
    // Complete the advanced search function
    $articles = complete_advanced_search($stmt, $bind_types, $bind_params);
    
    // Get facet data for categories
    $facets = [];
    
    // Category facets
    $facet_sql = "SELECT k.id, k.nama, k.slug, COUNT(a.id) as count 
                FROM kategori k
                LEFT JOIN artikel a ON k.id = a.kategori_id
                " . ($where_clause ? $where_clause . " AND a.id IS NOT NULL" : "WHERE a.id IS NOT NULL") . "
                GROUP BY k.id
                ORDER BY count DESC";
                
    $facet_stmt = $conn->prepare($facet_sql);
    
    if (!empty($bind_types)) {
        // We only need the search and filter params, not the pagination ones
        $facet_params = array_slice($bind_params, 0, count($bind_params) - 2);
        if (!empty($facet_params)) {
            $facet_bind_types = substr($bind_types, 0, strlen($bind_types) - 2);
            $facet_stmt->bind_param($facet_bind_types, ...$facet_params);
        }
    }
    
    $facet_stmt->execute();
    $facet_result = $facet_stmt->get_result();
    
    $category_facets = [];
    while ($row = $facet_result->fetch_assoc()) {
        $category_facets[] = $row;
    }
    
    $facets['categories'] = $category_facets;
    
    // Date facets (by month)
    $date_facet_sql = "SELECT 
                        DATE_FORMAT(a.tanggal_publikasi, '%Y-%m') as month,
                        COUNT(a.id) as count
                      FROM artikel a
                      JOIN kategori k ON a.kategori_id = k.id
                      " . ($where_clause ? $where_clause : "") . "
                      GROUP BY month
                      ORDER BY month DESC";
                      
    $date_facet_stmt = $conn->prepare($date_facet_sql);
    
    if (!empty($bind_types) && !empty($facet_params)) {
        $date_facet_stmt->bind_param($facet_bind_types, ...$facet_params);
    }
    
    $date_facet_stmt->execute();
    $date_facet_result = $date_facet_stmt->get_result();
    
    $date_facets = [];
    while ($row = $date_facet_result->fetch_assoc()) {
        $date_facets[] = $row;
    }
    
    $facets['dates'] = $date_facets;
    
    $pagination = [
        'total' => (int)$total,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($total / $limit)
    ];
    
    // Log the search query if provided
    if ($search_query) {
        log_search(str_replace('%', '', $search_query), $total);
    }
    
    send_response(200, 'Advanced search results retrieved successfully', [
        'query' => isset($params['q']) ? $params['q'] : '',
        'results' => $articles,
        'facets' => $facets,
        'pagination' => $pagination,
        'filters' => $params
    ]);
}

/**
 * Log search queries for analytics
 */
function log_search($query, $result_count) {
    global $conn;
    
    $sql = "INSERT INTO search_logs (query, result_count, search_date, ip_address) VALUES (?, ?, NOW(), ?)";
    $stmt = $conn->prepare($sql);
    $ip = $_SERVER['REMOTE_ADDR'];
    $stmt->bind_param("sis", $query, $result_count, $ip);
    $stmt->execute();
}

/**
 * Get trending searches
 */
function get_trending_searches($limit = 5) {
    global $conn;
    
    $sql = "SELECT query, COUNT(*) as search_count 
           FROM search_logs 
           WHERE search_date > DATE_SUB(NOW(), INTERVAL 7 DAY) 
           GROUP BY query 
           ORDER BY search_count DESC 
           LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $trending = [];
    while ($row = $result->fetch_assoc()) {
        $trending[] = $row;
    }
    
    return $trending;
}

/**
 * Get popular articles based on view count
 */
function get_popular_articles($limit = 5) {
    global $conn;
    
    $sql = "SELECT a.id, a.judul, a.slug, COUNT(DISTINCT v.session_id) as view_count 
           FROM artikel a 
           JOIN artikel_views v ON a.id = v.artikel_id 
           WHERE v.view_date > DATE_SUB(NOW(), INTERVAL 30 DAY) 
           GROUP BY a.id 
           ORDER BY view_count DESC 
           LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $articles = [];
    while ($row = $result->fetch_assoc()) {
        $articles[] = $row;
    }
    
    return $articles;
}